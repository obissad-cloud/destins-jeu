// Copie le jeu web compilé dans les assets de l'application mobile, en version « android » :
// sans AdSense (les pubs passent par AdMob côté natif) et avec les achats Google Play.
// Source : web/index.html si présent, sinon le jeu en ligne (utilisé par la compilation GitHub).
const fs = require("fs"), path = require("path"), https = require("https");
const dst = path.join(__dirname, "..", "assets", "jeu.html");
const propre = path.join(__dirname, "..", "jeu", "index.html"); // copie du jeu propre à l'appli (indépendante du site)
const local = fs.existsSync(propre) ? propre : path.join(__dirname, "..", "..", "web", "index.html");
function preparer(html) {
  fs.mkdirSync(path.dirname(dst), { recursive: true });
  html = html.replace(/<script async src="https:\/\/pagead2\.googlesyndication\.com\/[^"]*"[^>]*><\/script>\s*/g, "");
  html = html.replace("<head>", '<head>\n<script>window.DESTINS_PLATEFORME="android";window.DESTINS_GRATUIT=true;</script>');
  fs.writeFileSync(dst, html); console.log("Jeu copié :", (fs.statSync(dst).size / 1e6).toFixed(2), "Mo");
}
if (fs.existsSync(local)) preparer(fs.readFileSync(local, "utf8"));
else {
  const url = process.env.JEU_URL || "https://destins-jeu.pages.dev/";
  https.get(url, r => { let d = ""; r.setEncoding("utf8"); r.on("data", c => d += c); r.on("end", () => { if (r.statusCode !== 200 || d.length < 100000) { console.error("Téléchargement du jeu impossible", r.statusCode); process.exit(1); } preparer(d); }); }).on("error", e => { console.error(e); process.exit(1); });
}
