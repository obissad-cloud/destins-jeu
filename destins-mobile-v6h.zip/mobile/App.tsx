// Application mobile Destins : le jeu (moteur + interface web) tourne dans une WebView plein écran.
// Les sauvegardes utilisent le localStorage de la WebView, qui est conservé entre les lancements.
import React, { useEffect, useState } from "react";
import { ActivityIndicator, BackHandler, Linking, Platform, View } from "react-native";
import { SafeAreaProvider, SafeAreaView } from "react-native-safe-area-context";
import { StatusBar } from "expo-status-bar";
import { WebView } from "react-native-webview";
import { Asset } from "expo-asset";
import * as FileSystem from "expo-file-system";

// Version de test fermé : ni pubs ni achats (ils reviendront dans une mise à jour).

export default function App() {
  const [html, setHtml] = useState<string | null>(null);
  const web = React.useRef<WebView>(null);
  useEffect(() => {
    (async () => {
      const a = Asset.fromModule(require("./assets/jeu.html"));
      await a.downloadAsync();
      setHtml(await FileSystem.readAsStringAsync(a.localUri!));
    })();
    const sub = BackHandler.addEventListener("hardwareBackPress", () => true); // pas de sortie accidentelle
    return () => sub.remove();
  }, []);
  return (
    <SafeAreaProvider>
      <SafeAreaView style={{ flex: 1, backgroundColor: "#FFFFFF" }} edges={["top", "bottom"]}>
        <StatusBar style="dark" />
        {html ? (
          <WebView
            ref={web}
            originWhitelist={["*"]}
            source={{ html, baseUrl: "https://destins.local/" }}
            domStorageEnabled
            javaScriptEnabled
            allowsInlineMediaPlayback
            mediaPlaybackRequiresUserAction={false}
            setSupportMultipleWindows={false}
            onOpenWindow={e => Linking.openURL(e.nativeEvent.targetUrl)}
            overScrollMode="never"
            bounces={false}
            textZoom={100}
            style={{ flex: 1 }}
            onShouldStartLoadWithRequest={r => { if (r.url.startsWith("https://destins.local") || r.url.startsWith("about:") || r.url.startsWith("data:")) return true; if (/^https?:/.test(r.url)) { Linking.openURL(r.url); return false; } return Platform.OS === "ios"; }}
          />
        ) : (
          <View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}><ActivityIndicator size="large" color="#FFB020" /></View>
        )}
      </SafeAreaView>
    </SafeAreaProvider>
  );
}
