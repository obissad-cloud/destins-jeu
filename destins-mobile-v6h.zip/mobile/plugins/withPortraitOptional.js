// Déclare l'orientation portrait comme facultative pour Google Play
// (évite l'exclusion des tablettes, PC et autres appareils sans écran portrait).
const { withAndroidManifest } = require("expo/config-plugins");

module.exports = function withPortraitOptional(config) {
  return withAndroidManifest(config, (cfg) => {
    const manifest = cfg.modResults.manifest;
    manifest["uses-feature"] = manifest["uses-feature"] || [];
    const noms = ["android.hardware.screen.portrait", "android.hardware.screen.landscape"];
    for (const nom of noms) {
      const existant = manifest["uses-feature"].find((f) => f.$["android:name"] === nom);
      if (existant) existant.$["android:required"] = "false";
      else manifest["uses-feature"].push({ $: { "android:name": nom, "android:required": "false" } });
    }
    return cfg;
  });
};
