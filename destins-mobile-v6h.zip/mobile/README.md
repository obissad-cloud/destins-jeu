# Destins – application Android

Le jeu (destins-jeu.pages.dev) tourne dans une WebView. Achats : Google Play Billing. Pubs : AdMob.

- La compilation se lance toute seule à chaque modification (onglet **Actions**), ou à la main avec « Run workflow ».
- Résultat : l'artefact **destins-android** contient `destins.aab` (à envoyer sur Google Play) et `destins.apk` (à installer directement sur un téléphone pour tester).
- `cle/upload.jks` + `cle/motdepasse.txt` : clé de signature créée au premier lancement. **Ne jamais la supprimer** et garder ce dépôt **privé**.
- AdMob : remplacer `ADMOB_INTERSTITIEL` et `ADMOB_RECOMPENSE` dans `App.tsx`, et l'`androidAppId` dans `app.json`.
